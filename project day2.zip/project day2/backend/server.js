const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const Incident = require('./models/Incident');

dotenv.config();

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log("MongoDB connected");
}).catch((err) => {
  console.error("MongoDB connection error:", err);
});

// Routes

// Get all incidents
app.get('/api/incidents', async (req, res) => {
  try {
    const incidents = await Incident.find();
    res.json(incidents);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Add new incident
app.post('/api/incidents', async (req, res) => {
  const { title, description, status } = req.body;
  const incident = new Incident({
    title,
    description,
    status
  });

  try {
    const savedIncident = await incident.save();
    res.status(201).json(savedIncident);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Update an incident
app.put('/api/incidents/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const updatedIncident = await Incident.findByIdAndUpdate(id, req.body, { new: true });
    res.json(updatedIncident);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete an incident
app.delete('/api/incidents/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await Incident.findByIdAndDelete(id);
    res.json({ message: 'Incident deleted' });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
