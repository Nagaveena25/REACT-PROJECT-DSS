import React, { useState } from 'react';
import { X, Search, Paperclip, MoreHorizontal, Copy, Calendar } from 'lucide-react';
import { Incident } from '../types';

interface NewIncidentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (incident: Partial<Incident>) => void;
}

const NewIncidentModal: React.FC<NewIncidentModalProps> = ({ isOpen, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    caller: '',
    alternativeContact: '',
    location: '',
    category: '',
    subcategory: '',
    configurationItem: '',
    impact: 'Low',
    urgency: 'Low',
    priority: 'Low',
    shortDescription: '',
    description: '',
    channel: '',
    assignmentGroup: '',
    assignedTo: '',
    workNotes: '',
    additionalComments: ''
  });

  const [activeTab, setActiveTab] = useState('notes');
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    'Detection and Recording',
    'Investigation and Diagnosis', 
    'Resolution and Recovery',
    'Confirmation and Closure'
  ];

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      number: `INC${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
      status: 'New',
      opened: new Date().toISOString(),
      priority: formData.priority as Incident['priority'],
      impact: formData.impact as Incident['impact'],
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-center pt-8 z-50">
      <div className="bg-white w-full max-w-6xl mx-4 rounded-lg shadow-xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-blue-50">
          <div className="flex items-center gap-4">
            <button onClick={onClose} className="p-2 hover:bg-blue-100 rounded">
              <X size={20} />
            </button>
            <div className="flex items-center gap-2">
              <span className="text-lg font-semibold">Incident</span>
              <span className="text-gray-600">New record</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-blue-100 rounded">
              <Paperclip size={20} />
            </button>
            <button className="p-2 hover:bg-blue-100 rounded">
              <MoreHorizontal size={20} />
            </button>
            <button
              onClick={handleSubmit}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              Submit
            </button>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="flex bg-gray-100 border-b border-gray-200">
          {steps.map((step, index) => (
            <div
              key={index}
              className={`flex-1 px-4 py-3 text-center text-sm font-medium relative ${
                index === currentStep
                  ? 'bg-green-600 text-white'
                  : index < currentStep
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-600'
              }`}
            >
              {step}
              {index < steps.length - 1 && (
                <div className="absolute right-0 top-0 w-0 h-0 border-t-[24px] border-b-[24px] border-l-[12px] border-t-transparent border-b-transparent border-l-current"></div>
              )}
            </div>
          ))}
        </div>

        {/* Form Content */}
        <div className="flex-1 overflow-auto">
          <div className="grid grid-cols-2 gap-6 p-6">
            {/* Left Column */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Number</label>
                <input
                  type="text"
                  value="Auto-generated"
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-gray-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Caller <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={formData.caller}
                    onChange={(e) => setFormData({...formData, caller: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-10"
                    placeholder="Search for caller"
                  />
                  <Search className="absolute right-3 top-2.5 text-gray-400" size={16} />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Alternative Contact</label>
                <input
                  type="text"
                  value={formData.alternativeContact}
                  onChange={(e) => setFormData({...formData, alternativeContact: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50"
                  disabled
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">-- None --</option>
                  <option value="Hardware">Hardware</option>
                  <option value="Software">Software</option>
                  <option value="Network">Network</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Subcategory <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.subcategory}
                  onChange={(e) => setFormData({...formData, subcategory: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">-- None --</option>
                  <option value="Desktop">Desktop</option>
                  <option value="Laptop">Laptop</option>
                  <option value="Server">Server</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Configuration Item <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={formData.configurationItem}
                    onChange={(e) => setFormData({...formData, configurationItem: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-10"
                  />
                  <Search className="absolute right-3 top-2.5 text-gray-400" size={16} />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Impact <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value="4 - Low"
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-gray-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Urgency</label>
                <input
                  type="text"
                  value="4 - Low"
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-gray-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                <div className="bg-blue-50 border border-blue-200 rounded p-2 text-blue-800 text-sm">
                  4 - Low
                  <div className="text-xs mt-1">Please contact Servicedesk to change the priority.</div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Parent</label>
                <div className="relative">
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-10"
                  />
                  <Search className="absolute right-3 top-2.5 text-gray-400" size={16} />
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Opened</label>
                <input
                  type="text"
                  value="2025-09-11 06:48:41"
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-gray-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Opened by</label>
                <input
                  type="text"
                  value="Jyosthna Sagili"
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-gray-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Channel <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.channel}
                  onChange={(e) => setFormData({...formData, channel: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">-- None --</option>
                  <option value="Email">Email</option>
                  <option value="Phone">Phone</option>
                  <option value="Web">Web</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  State <span className="text-red-500">*</span>
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  defaultValue="New"
                >
                  <option value="New">New</option>
                  <option value="In Progress">In Progress</option>
                  <option value="On Hold">On Hold</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Assignment group <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={formData.assignmentGroup}
                    onChange={(e) => setFormData({...formData, assignmentGroup: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-10"
                  />
                  <Search className="absolute right-3 top-2.5 text-gray-400" size={16} />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Assigned to</label>
                <input
                  type="text"
                  value={formData.assignedTo}
                  onChange={(e) => setFormData({...formData, assignedTo: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50"
                  disabled
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Reassignment count</label>
                <input
                  type="text"
                  value="-1"
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-gray-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Reopen count</label>
                <input
                  type="text"
                  value="0"
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-gray-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Assigned to count</label>
                <input
                  type="text"
                  value="0"
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-gray-500"
                />
              </div>

              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2">
                  <input type="checkbox" className="rounded border-gray-300" />
                  <span className="text-sm text-gray-700">Wrong Assignment</span>
                </label>
              </div>

              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2">
                  <input type="checkbox" className="rounded border-gray-300" />
                  <span className="text-sm text-gray-700">Impact multiple</span>
                </label>
              </div>

              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2">
                  <input type="checkbox" className="rounded border-gray-300" />
                  <span className="text-sm text-gray-700">Prevent you from working</span>
                </label>
              </div>
            </div>
          </div>

          {/* Short Description and Description */}
          <div className="px-6 pb-4">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Short description <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <textarea
                  value={formData.shortDescription}
                  onChange={(e) => setFormData({...formData, shortDescription: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 h-20"
                  placeholder="Enter short description"
                />
                <div className="absolute bottom-2 left-2 flex gap-2">
                  <button className="p-1 text-gray-400 hover:text-gray-600">
                    <Copy size={16} />
                  </button>
                  <button className="p-1 text-gray-400 hover:text-gray-600">
                    <Calendar size={16} />
                  </button>
                </div>
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 h-24"
                placeholder="Enter detailed description"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">KBA Used</label>
              <div className="relative">
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-10"
                />
                <Search className="absolute right-3 top-2.5 text-gray-400" size={16} />
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="px-6">
            <div className="border-b border-gray-200 mb-4">
              <div className="flex gap-6">
                <button
                  onClick={() => setActiveTab('notes')}
                  className={`pb-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'notes'
                      ? 'border-green-500 text-green-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Notes
                </button>
                <button
                  onClick={() => setActiveTab('related')}
                  className={`pb-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'related'
                      ? 'border-green-500 text-green-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Related Records
                </button>
              </div>
            </div>

            {activeTab === 'notes' && (
              <div className="space-y-4 pb-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <label className="block text-sm font-medium text-gray-700">Watchlist</label>
                      <div className="flex gap-1">
                        <button className="p-1 border border-gray-300 rounded text-xs">📋</button>
                        <button className="p-1 border border-gray-300 rounded text-xs">👤</button>
                      </div>
                    </div>
                    <textarea className="w-full px-3 py-2 border border-gray-300 rounded h-24" />
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <label className="block text-sm font-medium text-gray-700">Work notes list</label>
                      <div className="flex gap-1">
                        <button className="p-1 border border-gray-300 rounded text-xs">📋</button>
                        <button className="p-1 border border-gray-300 rounded text-xs">👤</button>
                      </div>
                    </div>
                    <textarea className="w-full px-3 py-2 border border-gray-300 rounded h-24" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Work notes</label>
                  <textarea
                    value={formData.workNotes}
                    onChange={(e) => setFormData({...formData, workNotes: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded h-24"
                    placeholder="Enter work notes"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Additional comments (Customer visible)
                  </label>
                  <textarea
                    value={formData.additionalComments}
                    onChange={(e) => setFormData({...formData, additionalComments: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded h-24"
                    placeholder="Enter additional comments"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewIncidentModal;